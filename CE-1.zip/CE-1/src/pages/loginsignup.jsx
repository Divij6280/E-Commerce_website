import React from "react";
const loginsignup=()=>{
    return(
        <div>

        </div>
    )
}
export default loginsignup